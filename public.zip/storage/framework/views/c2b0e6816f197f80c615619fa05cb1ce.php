<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 class="text-2xl font-bold mb-6">Tracking Information</h1>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                <p class="font-bold">Please fix the following errors:</p>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="mb-6 p-4 bg-blue-50 rounded-md">
            <h2 class="text-lg font-semibold mb-2">Shipment Information</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <p class="text-sm text-gray-600">Tracking Number</p>
                    <p class="font-medium"><?php echo e($shipment->tracking_number); ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Service Type</p>
                    <p class="font-medium"><?php echo e($shipment->selectedRate ? $shipment->selectedRate->getServiceDisplayName() : 'Service Selected'); ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Ship Date</p>
                    <p class="font-medium"><?php echo e($shipment->preferred_ship_date->format('F j, Y')); ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Status</p>
                    <p class="font-medium"><?php echo e($trackingInfo['status'] ?? 'Pending'); ?></p>
                </div>
                <?php if(isset($trackingInfo['estimated_delivery'])): ?>
                <div>
                    <p class="text-sm text-gray-600">Estimated Delivery</p>
                    <p class="font-medium"><?php echo e($trackingInfo['estimated_delivery']); ?></p>
                </div>
                <?php endif; ?>
                <?php if(isset($trackingInfo['current_location'])): ?>
                <div>
                    <p class="text-sm text-gray-600">Current Location</p>
                    <p class="font-medium"><?php echo e($trackingInfo['current_location']); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="mb-6 p-4 bg-gray-50 rounded-md">
            <h2 class="text-lg font-semibold mb-2">Shipment Details</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <p class="text-sm text-gray-600">From</p>
                    <p class="font-medium"><?php echo e($shipment->pickup_city); ?>, <?php echo e($shipment->pickup_state); ?> <?php echo e($shipment->pickup_postal_code); ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">To</p>
                    <p class="font-medium"><?php echo e($shipment->recipient_city); ?>, <?php echo e($shipment->recipient_state); ?> <?php echo e($shipment->recipient_postal_code); ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Weight</p>
                    <p class="font-medium"><?php echo e($shipment->package_weight); ?> lbs</p>
                </div>
            </div>
        </div>

        <?php if(isset($trackingInfo['updates']) && count($trackingInfo['updates']) > 0): ?>
            <div class="mb-6">
                <h2 class="text-lg font-semibold mb-4">Tracking History</h2>
                <div class="relative">
                    <div class="absolute left-4 top-0 h-full w-0.5 bg-gray-200"></div>
                    <div class="space-y-6">
                        <?php $__currentLoopData = $trackingInfo['updates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="relative pl-10">
                                <div class="absolute left-2 top-2 h-4 w-4 rounded-full bg-blue-500"></div>
                                <div class="bg-white p-4 rounded-md shadow-sm border border-gray-200">
                                    <p class="text-sm text-gray-500"><?php echo e($update['timestamp']->format('F j, Y - g:i A')); ?></p>
                                    <p class="font-medium"><?php echo e($update['status']); ?></p>
                                    <p class="text-sm"><?php echo e($update['location']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="mb-6 p-4 bg-yellow-50 rounded-md">
                <p class="text-sm text-yellow-700">No tracking updates available yet. Please check back later.</p>
            </div>
        <?php endif; ?>

        <div class="mt-8">
            <a href="<?php echo e(route('fedex.shipment.details', $shipment)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Back to Shipment Details
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH S:\Projects\Web\Bagvoyaage\resources\views\fedex\tracking.blade.php ENDPATH**/ ?>